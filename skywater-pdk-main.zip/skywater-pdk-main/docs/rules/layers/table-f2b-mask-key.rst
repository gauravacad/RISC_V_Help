Explanation of symbols:

* ``-`` = Layer not created for the device
* ``+`` = Layer allowed to overlap
* ``C`` = CREATED
* ``nr`` = next revision

.. rubric:: Footnotes

.. [#fb1] For RCX information
