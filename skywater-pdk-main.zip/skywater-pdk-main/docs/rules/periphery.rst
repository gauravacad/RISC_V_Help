Periphery Rules
===============

.. include:: periphery-rules.rst
