.. list-table::
   :header-rows: 2
   :stub-columns: 1


   * - Parameter
     - W/L
     - Units
     - MODEL
     - 
     - 
     - 
     - 
     - EDR
     - 
     - 

   * - 
     - 
     - 
     - TT
     - FF
     - SS
     - FS
     - SF
     - NOM
     - MIN
     - MAX

   * - VTXNPAS
     - 0.14/0.15
     - V
     - 0.68
     - 0.52
     - 0.846
     - 0.846
     - 0.515
     - 0.669
     - 0.498
     - 0.839

   * - IDSNPAS
     - 0.14/0.15
     - µA
     - 0.0702
     - 0.0948
     - 0.0471
     - 0.0943
     - 0.0473
     - 68.2
     - 45.5
     - 90.8

   * - ILKNPAS
     - 0.14/0.15
     - LOG A
     - Max = -8.0
     - -9.73
     - -12.33
     - -9.1
     - 
     - 
     - 
     - 

