TODO: verification/drc/calibre
==============================
